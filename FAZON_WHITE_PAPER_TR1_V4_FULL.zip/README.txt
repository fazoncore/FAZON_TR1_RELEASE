FAZON WHITE PAPER TR-1
Version 4
Includes full PDF, Markdown, JSON, License, and visual cover.
